import java.util.Scanner;
public class DoubleTuition {
	public static void main(String[] args) {
	System.out.println("first enter tuition");
	Scanner input =new Scanner(System.in);
	double tuition=input.nextDouble();
	double increas=1.07;
	double stop=2*tuition;
	int year =0;
	do{
	tuition = tuition*increas; year++;
	}while (tuition <= stop);
	System.out.println("it will double in "+year+" years , with 7 percent increase");
}
}